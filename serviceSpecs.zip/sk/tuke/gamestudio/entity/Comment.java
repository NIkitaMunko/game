package sk.tuke.gamestudio.entity;


public class Comment {
    // TODO
}
