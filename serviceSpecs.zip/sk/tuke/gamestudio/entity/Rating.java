package sk.tuke.gamestudio.entity;


public class Rating {
    // TODO
}
